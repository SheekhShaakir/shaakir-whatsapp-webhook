# Shaakir WhatsApp Webhook

This is a simple Flask-based webhook for responding to incoming WhatsApp messages using Twilio.

## How to Deploy on Render.com

1. Fork this repository to your GitHub account.
2. Go to https://dashboard.render.com and create a new Web Service.
3. Connect your GitHub and select this repository.
4. Use the following settings:

- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python main.py`

5. Once deployed, use the URL (e.g. `https://shaakir-webhook.onrender.com/sms`) in your Twilio WhatsApp sandbox webhook settings.

